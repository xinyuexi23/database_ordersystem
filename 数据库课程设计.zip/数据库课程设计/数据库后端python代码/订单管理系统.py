# -*- coding: utf-8 -*-

"""
外卖订单管理系统
命令行界面实现
"""

from 数据库连接 import Database
from tabulate import tabulate
from datetime import datetime

class OrderSystem:
    def __init__(self):
        self.db = None
        self.current_user = None
    
    def login(self, test_mode=False, test_user="王锦城", test_pwd="wjc942BX"):
        """
        用户登录功能
        :param test_mode: 是否为测试模式
        :param test_user: 测试用户名
        :param test_pwd: 测试密码
        """
        print("=" * 30)
        print("   外卖订单管理系统")
        print("=" * 30)
        
        # 连接数据库
        try:
            self.db = Database(
                server='192.168.78.136',
                database='orders_806',
                username='sa',
                password='byynbjzx_527'
            )
        except Exception as e:
            print(f"数据库连接失败: {e}")
            return False
        
        if test_mode:
            # 测试模式，使用预设的用户名和密码
            username = test_user
            password = test_pwd
            print(f"测试模式，使用默认用户: {username}")
        else:
            # 用户验证
            max_attempts = 3
            for attempt in range(max_attempts):
                username = input("请输入用户名: ")
                password = input("请输入密码: ")
                
                if not username or not password:
                    print("用户名和密码不能为空！")
                    continue
                break
            else:
                print("登录失败次数过多，系统退出")
                self.db.disconnect()
                return False
        
        # 查询用户 - 注意：user是SQL关键字，需要用方括号括起来
        # 注意：username字段是nchar类型，会自动填充空格，所以需要使用LIKE或TRIM
        sql = "SELECT * FROM [user] WHERE RTRIM(username) = ? AND password = ?"
        user = self.db.execute_query_one(sql, (username, password))
        
        if user:
            self.current_user = user
            print(f"\n欢迎您，{username}！")
            print("登录成功")
            print("=" * 30)
            return True
        else:
            print("用户名或密码错误！")
            self.db.disconnect()
            return False
    
    def show_menu(self):
        """
        显示系统主菜单
        """
        while True:
            print("\n" + "=" * 30)
            print("      系统菜单")
            print("=" * 30)
            print("---1. 查看商品信息---")
            print("---2. 查看订单信息---")
            print("---3. 查看配送信息---")
            print("---4. 添加订单---")
            print("---5. 更新订单状态---")
            print("---6. 更新配送信息---")
            print("---7. 查询订单---")
            print("---8. 删除订单---")
            print("---9. 删除配送信息---")
            print("---10. 退出系统---")
            print("=" * 30)
            
            choice = input("请输入操作编号: ")
            
            if choice == "1":
                self.view_goods()
            elif choice == "2":
                self.view_orders()
            elif choice == "3":
                self.view_deliveries()
            elif choice == "4":
                self.add_order()
            elif choice == "5":
                self.update_order_status()
            elif choice == "6":
                self.update_delivery()
            elif choice == "7":
                self.query_orders()
            elif choice == "8":
                self.delete_order()
            elif choice == "9":
                self.delete_delivery()
            elif choice == "10":
                self.exit_system()
                break
            else:
                print("输入错误，请重新输入！")
    
    def view_goods(self, test_mode=False):
        """
        查看商品信息
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 商品列表 ===")
        sql = "SELECT * FROM Goods"
        goods = self.db.execute_query(sql)
        
        if not goods:
            print("暂无商品数据。")
            if not test_mode:
                input("\n按Enter键返回菜单...")
            return
        
        headers = ['商品ID', '商品名称', '价格', '库存', '运费', '折扣']
        table_data = []
        for good in goods:
            g_id, g_name, g_price, store, g_freight, g_discount = good
            row = [g_id, g_name, round(float(g_price), 2) if g_price else 0.0,
                   store, round(float(g_freight), 2) if g_freight else 0.0,
                   round(float(g_discount), 2) if g_discount else 0.0]
            table_data.append(row)
        
        print(tabulate(table_data, headers=headers, tablefmt="grid", floatfmt=".2f"))
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def view_orders(self, test_mode=False):
        """
        查看订单信息
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 订单列表 ===")
        sql = "SELECT o.*, u.username FROM Orders o JOIN [user] u ON o.u_id = u.U_id"
        orders = self.db.execute_query(sql)
        
        if not orders:
            print("暂无订单数据。")
            if not test_mode:
                input("\n按Enter键返回菜单...")
            return
        
        headers = ['订单ID', '用户', '支付状态', '支付方式', '支付时间', '创建时间', '实付价格', '订单状态']
        table_data = []
        
        for order in orders:
            o_id, u_id, pay_status, pay_method, pay_time, create_time, real_price, order_status, username = order
            
            pay_status_text = "已支付" if pay_status else "未支付"
            pay_time_str = pay_time.strftime("%m-%d %H:%M") if pay_time else "-"
            create_time_str = create_time.strftime("%m-%d %H:%M") if create_time else "-"
            real_price = round(float(real_price), 2) if real_price else 0.0
            
            row = [
                o_id,
                username,
                pay_status_text,
                pay_method,
                pay_time_str,
                create_time_str,
                real_price,
                order_status
            ]
            table_data.append(row)
        
        print(tabulate(table_data, headers=headers, tablefmt="grid", floatfmt=".2f", maxcolwidths=[None, 10, None, None, 12, 12, None, None]))
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def view_deliveries(self, test_mode=False):
        """
        查看配送信息
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 配送信息 ===")
        sql = """
            SELECT d.delivery_id, d.o_id, d.logistics_company, d.receiver_name, 
                   d.receiver_tel, d.receiver_address, d.delivery_status, 
                   u.username 
            FROM Delivery d 
            JOIN Orders o ON d.o_id = o.o_id 
            JOIN [user] u ON o.u_id = u.U_id
        """
        deliveries = self.db.execute_query(sql)
        
        if not deliveries:
            print("暂无配送信息。")
            if not test_mode:
                input("\n按Enter键返回菜单...")
            return
        
        headers = ['配送ID', '订单ID', '用户名', '物流公司', '收货人', '联系电话', '配送状态', '收货地址']
        table_data = []
        
        for d in deliveries:
            delivery_id, o_id, logistics_company, receiver_name, receiver_tel, receiver_address, delivery_status, username = d
            
            short_address = (receiver_address[:12] + '...') if receiver_address and len(receiver_address) > 12 else receiver_address
            
            row = [
                delivery_id,
                o_id,
                username,
                logistics_company if logistics_company else "未指定",
                receiver_name,
                receiver_tel,
                delivery_status,
                short_address
            ]
            table_data.append(row)
        
        print(tabulate(table_data, headers=headers, tablefmt="grid", maxcolwidths=[None, None, 10, 10, 8, 12, 8, 15]))
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def add_order(self, test_mode=False):
        """
        添加新订单
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 添加订单 ===")
        
        # 查看可用商品
        self.view_goods(test_mode=test_mode)
        
        # 获取订单信息
        try:
            goods_id = int(input("商品ID: "))
            quantity = int(input("数量: "))
            
            # 支付方式验证
            valid_pay_methods = ['微信', '支付宝']
            pay_method = input("支付方式(微信/支付宝): ")
            if pay_method not in valid_pay_methods:
                print("支付方式错误！请选择微信或支付宝。")
                return
            
            # 验证商品库存
            goods = self.db.execute_query_one("SELECT * FROM Goods WHERE g_id = ?", (goods_id,))
            if not goods:
                print("商品不存在！")
                return
            
            if goods[3] < quantity:
                print(f"库存不足！当前库存: {goods[3]}")
                return
            
            # 计算订单金额
            g_price = float(goods[2]) if goods[2] else 0.0
            g_freight = float(goods[4]) if goods[4] else 0.0
            g_discount = float(goods[5]) if goods[5] else 0.0
            total_price = g_price * quantity
            real_price = total_price * g_discount + g_freight
            
            # 查询当前最大的O_id
            max_o_id = self.db.execute_query_one("SELECT ISNULL(MAX(O_id), 0) + 1 FROM Orders")[0]
            
            # 添加订单
            sql_order = "INSERT INTO Orders (O_id, u_id, pay_status, pay_method, create_time, real_price, order_status) VALUES (?, ?, ?, ?, GETDATE(), ?, ?)"
            params_order = (max_o_id, self.current_user[0], 1, pay_method, real_price, "待配送")
            
            if self.db.execute_insert(sql_order, params_order):
                
                # 添加订单商品明细
                sql_item = "INSERT INTO Order_items (o_id, g_id, num, item_price) VALUES (?, ?, ?, ?)"
                params_item = (max_o_id, goods_id, quantity, g_price)
                self.db.execute_insert(sql_item, params_item)
                
                # 更新商品库存
                sql_update = "UPDATE Goods SET store = store - ? WHERE g_id = ?"
                self.db.execute_update(sql_update, (quantity, goods_id))
                
                print(f"✅ 下单成功！订单ID: {max_o_id}")
                print(f"📦 商品总价: {total_price:.2f}元")
                print(f"💸 折扣: {g_discount:.2f}")
                print(f"🚚 运费: {g_freight:.2f}元")
                print(f"💰 实付金额: {real_price:.2f}元")
            else:
                print("❌ 订单添加失败！")
                
        except ValueError:
            print("⚠️ 输入格式错误！请输入有效的数字")
        except Exception as e:
            print(f"❌ 添加订单失败: {e}")
        
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def update_order_status(self, test_mode=False):
        """
        更新订单状态
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 更新订单状态 ===")
        
        # 查看当前订单
        self.view_orders(test_mode=test_mode)
        
        try:
            order_id = int(input("请输入要更新的订单ID: "))
            
            # 订单状态验证
            valid_order_status = ['已取消', '已完成', '配送中', '待配送', '待接单', '待支付']
            new_status = input(f"请输入新的订单状态({', '.join(valid_order_status)}): ")
            
            if new_status not in valid_order_status:
                print(f"⚠️ 状态错误！仅支持：{', '.join(valid_order_status)}")
                return
            
            sql = "UPDATE Orders SET order_status = ? WHERE o_id = ?"
            if self.db.execute_update(sql, (new_status, order_id)):
                print(f"✅ 订单 {order_id} 状态更新为「{new_status}」成功！")
            else:
                print(f"❌ 订单 {order_id} 状态更新失败！")
                
        except ValueError:
            print("⚠️ 输入格式错误！订单ID必须为数字")
        except Exception as e:
            print(f"⚠️ 更新订单状态失败: {str(e)}")
        
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def update_delivery(self, test_mode=False):
        """
        更新配送信息
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 更新配送信息 ===")
        
        # 查看当前配送信息
        self.view_deliveries(test_mode=test_mode)
        
        try:
            order_id = int(input("订单ID: "))
            logistics_company = input("物流公司: ")
            receiver_name = input("收货人: ")
            receiver_tel = input("联系电话: ")
            receiver_address = input("收货地址: ")
            
            # 配送状态验证
            valid_delivery_status = ['已签收', '配送中', '待配送']
            delivery_status = input(f"配送状态({', '.join(valid_delivery_status)}): ")
            
            # 数据验证
            if not logistics_company or not receiver_name or not receiver_tel or not receiver_address:
                print("⚠️ 物流公司、收货人、联系电话和收货地址不能为空！")
                return
            
            if delivery_status not in valid_delivery_status:
                print(f"⚠️ 状态错误！仅支持: {', '.join(valid_delivery_status)}")
                return
            
            # 检查订单是否存在
            order_exists = self.db.execute_query_one("SELECT 1 FROM Orders WHERE o_id=?", (order_id,))
            if not order_exists:
                print("⚠️ 订单ID不存在，请检查后重试！")
                return
            
            # 检查是否已有配送信息
            delivery_exists = self.db.execute_query_one("SELECT 1 FROM Delivery WHERE o_id=?", (order_id,))
            
            if delivery_exists:
                # 更新配送信息
                sql = "UPDATE Delivery SET logistics_company = ?, receiver_name = ?, receiver_tel = ?, receiver_address = ?, delivery_status = ? WHERE o_id = ?"
                if self.db.execute_update(sql, (logistics_company, receiver_name, receiver_tel, receiver_address, delivery_status, order_id)):
                    print(f"✅ 订单 {order_id} 配送信息更新成功！")
            else:
                # 添加配送信息
                sql = "INSERT INTO Delivery (o_id, logistics_company, receiver_name, receiver_tel, receiver_address, delivery_status) VALUES (?, ?, ?, ?, ?, ?)"
                if self.db.execute_insert(sql, (order_id, logistics_company, receiver_name, receiver_tel, receiver_address, delivery_status)):
                    print(f"✅ 订单 {order_id} 配送信息添加成功！")
            
        except ValueError:
            print("⚠️ 订单ID必须为数字！")
        except Exception as e:
            print(f"❌ 操作失败: {str(e)}")
        
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def query_orders(self, test_mode=False):
        """
        查询订单
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 查询订单 ===")
        print("1. 按订单ID查询")
        print("2. 按用户查询")
        print("3. 按订单状态查询")
        choice = input("请选择查询方式: ")

        # 定义要查询的字段
        field_names = ['订单ID', '用户ID', '支付状态', '支付方式', '支付时间', '创建时间', '实付价格', '订单状态', '用户名']
        
        try:
            # 根据用户选择构建不同的SQL
            if choice == "1":
                o_id = int(input("订单ID: "))
                sql = "SELECT o.*, u.username FROM Orders o JOIN [user] u ON o.u_id=u.U_id WHERE o.o_id=?"
                params = (o_id,)
                
            elif choice == "2":
                uname = input("用户名: ")
                sql = "SELECT o.*, u.username FROM Orders o JOIN [user] u ON o.u_id=u.U_id WHERE u.username=?"
                params = (uname,)
                
            elif choice == "3":
                status = input("订单状态: ")
                sql = "SELECT o.*, u.username FROM Orders o JOIN [user] u ON o.u_id=u.U_id WHERE o.order_status=?"
                params = (status,)
                
            else:
                print("❌ 查询方式错误！请输入 1/2/3 选择！")
                return

            # 执行查询
            results = self.db.execute_query(sql, params)

            # 处理并显示结果
            if not results:
                print("📭 未查询到相关订单。")
            else:
                print(f"\n--- 查询结果 ({len(results)}条) ---")
                for index, row in enumerate(results, start=1):
                    print(f"\n【匹配结果 {index}】")
                    # 把每行数据和字段名做映射，遍历打印
                    for field_name, value in zip(field_names, row):
                        if field_name == "支付状态":
                            value = "已支付" if value else "未支付"
                        elif field_name in ["支付时间", "创建时间"]:
                            value = value.strftime("%Y-%m-%d %H:%M") if value else "-"
                        elif field_name == "实付价格":
                            value = f"{float(value):.2f}" if value else "0.00"
                        print(f"  {field_name}: {value}")

        except ValueError:
            print("⚠️ 输入格式错误！订单ID必须为纯数字！")
        except IndexError:
            print("❌ 数据字段匹配异常！请检查SQL查询字段和字段列表是否一致！")
        except Exception as e:
            print(f"❌ 查询失败【{type(e).__name__}】: {str(e)}")

        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def delete_order(self, test_mode=False):
        """
        删除订单
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 删除订单 ===")
        
        # 先显示订单列表，方便用户选择
        self.view_orders(test_mode=True)
        
        try:
            order_id = int(input("请输入要删除的订单ID: "))
            
            # 检查订单是否存在
            order_exists = self.db.execute_query_one("SELECT 1 FROM Orders WHERE o_id=?", (order_id,))
            if not order_exists:
                print("❌ 订单ID不存在！")
                return
            
            # 确认删除
            confirm = input(f"确定要删除订单ID为 {order_id} 的订单吗？(y/n): ")
            if confirm.lower() != 'y':
                print("✅ 删除操作已取消")
                return
            
            # 级联删除相关数据（订单商品明细和配送信息）
            # 1. 删除配送信息
            self.db.execute_update("DELETE FROM Delivery WHERE o_id=?", (order_id,))
            # 2. 删除订单商品明细
            self.db.execute_update("DELETE FROM Order_items WHERE o_id=?", (order_id,))
            # 3. 删除订单
            rows_deleted = self.db.execute_update("DELETE FROM Orders WHERE o_id=?", (order_id,))
            
            if rows_deleted > 0:
                print(f"✅ 订单ID {order_id} 删除成功！")
                print("   已级联删除相关的配送信息和订单商品明细")
            else:
                print(f"❌ 订单ID {order_id} 删除失败！")
                
        except ValueError:
            print("⚠️ 输入格式错误！订单ID必须为数字")
        except Exception as e:
            print(f"❌ 删除订单失败【{type(e).__name__}】: {str(e)}")
        
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def delete_delivery(self, test_mode=False):
        """
        删除配送信息
        :param test_mode: 是否为测试模式，测试模式下不等待用户输入
        """
        print("\n=== 删除配送信息 ===")
        
        # 先显示配送信息列表，方便用户选择
        self.view_deliveries(test_mode=True)
        
        try:
            order_id = int(input("请输入要删除配送信息的订单ID: "))
            
            # 检查配送信息是否存在
            delivery_exists = self.db.execute_query_one("SELECT 1 FROM Delivery WHERE o_id=?", (order_id,))
            if not delivery_exists:
                print("❌ 该订单没有对应的配送信息！")
                return
            
            # 确认删除
            confirm = input(f"确定要删除订单ID为 {order_id} 的配送信息吗？(y/n): ")
            if confirm.lower() != 'y':
                print("✅ 删除操作已取消")
                return
            
            # 执行删除
            rows_deleted = self.db.execute_update("DELETE FROM Delivery WHERE o_id=?", (order_id,))
            
            if rows_deleted > 0:
                print(f"✅ 订单ID {order_id} 的配送信息删除成功！")
            else:
                print(f"❌ 订单ID {order_id} 的配送信息删除失败！")
                
        except ValueError:
            print("⚠️ 输入格式错误！订单ID必须为数字")
        except Exception as e:
            print(f"❌ 删除配送信息失败【{type(e).__name__}】: {str(e)}")
        
        if not test_mode:
            input("\n按Enter键返回菜单...")
    
    def exit_system(self):
        """
        退出系统
        """
        print("\n" + "=" * 30)
        print("感谢使用外卖订单管理系统！")
        print("=" * 30)
        if self.db:
            self.db.disconnect()
    
    def run(self):
        """
        运行系统
        """
        if self.login():
            self.show_menu()

# 主程序入口
if __name__ == "__main__":
    import sys
    
    # 检查是否有测试模式参数
    test_mode = len(sys.argv) > 1 and sys.argv[1] == "--test"
    
    system = OrderSystem()
    if test_mode:
        # 测试模式：自动登录并运行菜单
        if system.login(test_mode=True):
            # 显示菜单后立即退出，用于测试
            system.show_menu()
    else:
        system.run()