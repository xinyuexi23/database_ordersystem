# -*- coding: utf-8 -*-

#准备工作：1.安装ODBC  2.安装Python第三方库

import pyodbc #SQL Server 数据库
# import pymysql #MySQL 数据库

#1.SQL Server 数据库连接代码
# 连接字符串格式
# DRIVER={SQL Server};SERVER=服务器地址;DATABASE=数据库名;UID=用户名;PWD=密码
connect_str = 'DRIVER={ODBC Driver 18 for SQL Server};' \
           'SERVER=192.168.78.136;' \
           'DATABASE=ORDER_SYSTEM;' \
           'UID=sa;PWD=byynbjzx_527;' \
           'Encrypt=yes;' \
           'TrustServerCertificate=yes;'

#创建连接
connect = pyodbc.connect(connect_str)

#2.MySQL 数据库连接代码
# connect = pymysql.connect(host='localhost', user='root',password='Sa123456', database='test')

if connect:
    print("连接成功")

#数据库操作思路：创建一个游标对象，python里的sql语句都要通过cursor来执行
cursor = connect.cursor()

# 示例：执行一个简单查询OK
cursor.execute("SELECT TOP 5 * FROM Users")
rows = cursor.fetchall()
print("查询结果：")
for row in rows:
    print(row)

# 查看存储过程OK
# cursor.execute('exec Proc_GetUserOrders @username=?','王锦城')
# rows = cursor.fetchall()
# print("查询结果：")
# for row in rows:
#     print(row)
# # 关闭连接
# cursor.close()
# connect.close()



# 示例：添加表OK
# sql = """create table suppliers(   s_id char(3) primary key,   s_name varchar(16),   s_add varchar(32)) """
# cursor.execute(sql)#执行建表操作
# connect.commit()

#添加数据--直接添加OK
# sql_insert="""
# insert into [user] values
# (100011,'马飞','qwerty','男','17756982347','开封市龙亭区宋都御街')
# """
# cursor.execute(sql_insert) #直接执行添加操作
# connect.commit()

#添加数据--存储过程添加OK
# sql_pro = "exec Proc_AddNewOrder ?, ?, ?, ?, ?, ?, ?, ?"  # 用?作为占位符
# params = (6, '100011', 1, '微信', 18.20, '已发货', '2026-1-6 10:22:00', '2026-1-6 10:20:00')  # 参数列表（保持类型正确）
# cursor.execute(sql_pro, params)  # 传递SQL和参数列表
# connect.commit()
# print("插入成功")


#删除数据OK
# sql_delete="delete from orders where O_id = 6"
# cursor.execute(sql_delete)#执行删除操作
# connect.commit()
# print("删除成功")

#更新数据OK
# sql_update="update [user] set password='wjc942BX' where username='王锦城'"
# cursor.execute(sql_update)#执行更新操作
# connect.commit()
# print("更新成功")

#数据查询
#sql_select="SELECT * FROM suppliers"  #数据库查询语句
#cursor.execute(sql_select) #执行查询操作，需要获取记录列表

# 查询全部：fetchall()方法
# results =cursor.fetchall() #fetchall()方法可以获取查询结果的所有记录,返回多个元组(tuple)组成的列表(list)
# for i in results:
#    print(i)
# 也可在循环中加if条件完成单条

#查询单条：fetchone()方法
#result=cursor.fetchone() #fetchone()方法可以获取列表的第一行数据,并返回一个元组(tuple)
#也可在循环中输出后，再加一句cursor.fetchone()完成全部查询


# cursor.close()#释放游标
# connect.close()#释放连接对象