# -*- coding: utf-8 -*-

"""
数据库连接与操作类
实现了SQL Server数据库的增删改查功能
"""

import pyodbc

class Database:
    def __init__(self, server, database, username, password, driver='ODBC Driver 18 for SQL Server'):
        """
        初始化数据库连接
        :param server: 192.168.78.129
        :param database: ORDER_SYSTEM
        :param username: sa
        :param password: byynbjzx_527
        :param driver: ODBC Driver 18 for SQL Server
        """
        self.connect_str = f'DRIVER={{{driver}}};SERVER={server};DATABASE={database};UID={username};PWD={password};Encrypt=yes;TrustServerCertificate=yes;'
        self.connect = None
        self.cursor = None
        self.connect_database()
    
    def connect_database(self):
        """
        建立数据库连接
        """
        try:
            self.connect = pyodbc.connect(self.connect_str)
            self.cursor = self.connect.cursor()
            print("数据库连接成功")
        except Exception as e:
            print(f"数据库连接失败: {e}")
    
    def disconnect(self):
        """
        关闭数据库连接
        """
        if self.cursor:
            self.cursor.close()
        if self.connect:
            self.connect.close()
            print("数据库连接已关闭")
    
    def execute_query(self, sql, params=None):
        """
        执行查询操作
        :param sql: SQL查询语句
        :param params: 查询参数（可选）
        :return: 查询结果列表
        """
        try:
            if params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            results = self.cursor.fetchall()
            return results
        except Exception as e:
            print(f"查询失败: {e}")
            return []
    
    def execute_query_one(self, sql, params=None):
        """
        执行单条查询操作
        :param sql: SQL查询语句
        :param params: 查询参数（可选）
        :return: 查询结果（单个元组）
        """
        try:
            if params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            result = self.cursor.fetchone()
            return result
        except Exception as e:
            print(f"查询失败: {e}")
            return None
    
    def execute_insert(self, sql, params=None):
        """
        执行插入操作
        :param sql: SQL插入语句
        :param params: 插入参数（可选）
        :return: 是否成功
        """
        try:
            if params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            self.connect.commit()
            print("插入成功")
            return True
        except Exception as e:
            print(f"插入失败: {e}")
            self.connect.rollback()
            return False
    
    def execute_update(self, sql, params=None):
        """
        执行更新操作
        :param sql: SQL更新语句
        :param params: 更新参数（可选）
        :return: 是否成功
        """
        try:
            if params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            self.connect.commit()
            print("更新成功")
            return True
        except Exception as e:
            print(f"更新失败: {e}")
            self.connect.rollback()
            return False
    
    def execute_delete(self, sql, params=None):
        """
        执行删除操作
        :param sql: SQL删除语句
        :param params: 删除参数（可选）
        :return: 是否成功
        """
        try:
            if params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            self.connect.commit()
            print("删除成功")
            return True
        except Exception as e:
            print(f"删除失败: {e}")
            self.connect.rollback()
            return False
    
    def execute_stored_procedure(self, proc_name, params=None):
        """
        执行存储过程
        :param proc_name: 存储过程名称
        :param params: 存储过程参数（可选）
        :return: 存储过程执行结果
        """
        try:
            sql = f"exec {proc_name}"
            if params:
                # 构建带参数占位符的存储过程调用语句
                placeholders = ', '.join(['?'] * len(params))
                sql = f"exec {proc_name} {placeholders}"
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            
            # 检查是否有结果集
            results = []
            while True:
                rows = self.cursor.fetchall()
                if rows:
                    results.extend(rows)
                if not self.cursor.nextset():
                    break
            
            self.connect.commit()
            print(f"存储过程 {proc_name} 执行成功")
            return results
        except Exception as e:
            print(f"存储过程执行失败: {e}")
            self.connect.rollback()
            return []

# 使用示例
if __name__ == "__main__":
    # 创建数据库连接实例
    db = Database(
        server='192.168.78.129',
        database='ORDER_SYSTEM',
        username='sa',
        password='byynbjzx_527'
    )
    
    # 示例1：查询数据
    print("\n=== 查询示例 ===")
    sql_select = "SELECT TOP 5 * FROM Users"
    results = db.execute_query(sql_select)
    for row in results:
        print(row)
    
    # 示例2：插入数据
    print("\n=== 插入示例 ===")
    # 注意：根据实际表结构调整插入语句
    # sql_insert = "INSERT INTO [user] (id, username, password, gender, phone, address) VALUES (?, ?, ?, ?, ?, ?)"
    # params_insert = (100012, '测试用户', 'test123', '男', '13800138000', '北京市朝阳区')
    # db.execute_insert(sql_insert, params_insert)
    
    # 示例3：更新数据
    print("\n=== 更新示例 ===")
    # 注意：根据实际表结构调整更新语句
    # sql_update = "UPDATE [user] SET password = ? WHERE username = ?"
    # params_update = ('newpassword123', '测试用户')
    # db.execute_update(sql_update, params_update)
    
    # 示例4：删除数据
    print("\n=== 删除示例 ===")
    # 注意：根据实际表结构调整删除语句
    # sql_delete = "DELETE FROM [user] WHERE username = ?"
    # params_delete = ('测试用户',)
    # db.execute_delete(sql_delete, params_delete)
    
    # 示例5：执行存储过程
    print("\n=== 存储过程示例 ===")
    # proc_results = db.execute_stored_procedure('Proc_GetUserOrders', params=('王锦城',))
    # for row in proc_results:
    #     print(row)
    
    # 关闭数据库连接
    db.disconnect()