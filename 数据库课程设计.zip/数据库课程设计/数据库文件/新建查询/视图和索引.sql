alter table goods add constraint df_discount default 1.00 for discount;
--��ͼ
create view v_user_order_detail
as
select [user].username,orders.O_id,goods.g_name,delivery.delivery_status
from [user]
join orders
on [user].U_id=orders.u_id
join order_items
on orders.O_id=order_items.o_id
join goods
on order_items.g_id=goods.G_id
join delivery
on delivery.o_id=orders.O_id

select *
from v_user_order_detail
where username='������'


ALTER VIEW v_user_order_detail
AS
SELECT
    u.username,
    o.o_id,
    -- �ϲ�ͬһ��������Ʒ����
    STUFF((
        SELECT ',' + g.g_name
        FROM dbo.order_items oi
        JOIN dbo.goods g ON oi.g_id = g.g_id
        WHERE oi.o_id = o.o_id
        FOR XML PATH(''), TYPE
    ).value('.', 'NVARCHAR(MAX)'), 1, 1, '') AS ��Ʒ�б�,
    o.real_price AS ����Ӧ�����, -- ����orders��real_price
    d.delivery_status
FROM dbo.[user] u
JOIN dbo.orders o ON u.u_id = o.u_id
JOIN dbo.order_items oi ON o.o_id = oi.o_id
JOIN dbo.goods g ON oi.g_id = g.g_id
JOIN dbo.delivery d ON o.o_id = d.o_id
GROUP BY u.username, o.o_id, o.real_price, d.delivery_status;


--�����������
create nonclustered index IX_orders_u_id
on orders(u_id);

create NONCLUSTERED INDEX IX_order_items_o_id
ON dbo.order_items(o_id);


CREATE NONCLUSTERED INDEX IX_delivery_o_id
ON dbo.delivery(o_id);

create nonclustered index IX_orders_username
on [user](username);

create nonclustered index IX_delivery_status
on delivery(delivery_status);










